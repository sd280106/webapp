const API_URL = "http://localhost:8000/api/weather/";

document.addEventListener("DOMContentLoaded", fetchWeather);

document.getElementById("addCityButton").addEventListener("click", async () => {
    const cityName = document.getElementById("cityInput").value.trim();
    if (!cityName) return alert("Enter a city name");

    const response = await fetch(`${API_URL}add/`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            name: cityName,
            temperature: (Math.random() * 30).toFixed(1),
            condition: "Cloudy"
        }),
    });

    const result = await response.json();
    if (response.ok) {
        alert("City added successfully! ✅");
        fetchWeather(); // Refresh the city list
    } else {
        alert("❌ Error adding city: " + result.error);
    }
});

async function fetchWeather() {
    const response = await fetch(API_URL);
    const cities = await response.json();

    const weatherContainer = document.getElementById("weatherContainer");
    weatherContainer.innerHTML = "";

    cities.forEach(city => {
        const weatherCard = document.createElement("div");
        weatherCard.className = "weather-card";
        weatherCard.innerHTML = `
            <h3>${city.name}</h3>
            <p>${city.temperature}°C</p>
            <p>${city.condition}</p>
            <button onclick="removeCity('${city.name}')">❌ Remove</button>
        `;
        weatherContainer.appendChild(weatherCard);
    });
}

async function removeCity(cityName) {
    await fetch(`${API_URL}remove/${cityName}/`, { method: "DELETE" });
    fetchWeather();
}
