# My Bulma Template

View it here: https://htmlpreview.github.io/?https://github.com/cfoh/bulma-template/main/index.html

Bulma doc: https://bulma.io/documentation/

Bulma CSS Source: https://github.com/jgthms/bulma

Uploaded Bulma version: 0.9.4

# CSS Source
```
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.4/css/bulma.min.css"/>
```
