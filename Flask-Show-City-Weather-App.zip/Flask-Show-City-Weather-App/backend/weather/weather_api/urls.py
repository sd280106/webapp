from django.urls import path
from .views import get_weather, add_city, remove_city

urlpatterns = [
    path('api/weather/', get_weather, name="get_weather"),
    path('api/weather/add/', add_city, name="add_city"),
    path('api/weather/remove/<str:city_name>/', remove_city, name="remove_city"),
]
