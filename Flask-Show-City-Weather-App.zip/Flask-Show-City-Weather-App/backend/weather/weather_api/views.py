from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import City
from .serializers import CitySerializer

@api_view(['GET'])
def get_weather(request):
    cities = City.objects.all()
    serializer = CitySerializer(cities, many=True)
    return Response(serializer.data)

@csrf_exempt
@api_view(['POST'])
def add_city(request):
    serializer = CitySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "City added successfully"}, status=201)
    return Response(serializer.errors, status=400)

@api_view(['DELETE'])
def remove_city(request, city_name):
    try:
        city = City.objects.get(name=city_name)
        city.delete()
        return Response({"message": "City removed successfully"}, status=200)
    except City.DoesNotExist:
        return Response({"error": "City not found"}, status=404)
